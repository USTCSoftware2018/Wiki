# Attributions

## Developing

![bioLogo.](/Users/xiebohao/Desktop/wiki_pages/Attribution/bioLogo..png)

We sincerely thank team **USTC-Software-2017**, who gave us much advice, and their project, **Biohub 2.0**, from which our project got helped.

We sincerely thank all the free software that we use like **Vue.js**, **axios**, and **webpack**. They are the foundation of our project.

## Support

![support](/Users/xiebohao/Desktop/wiki_pages/Attribution/support.png)

We sincerely thank our advisors--**Professor Liu Haiyan**, who helped us determine the topic of our project, and **Dr. Hong Jiong**, who gave us lots of valuable advice in basic biology during our working process.

We sincerely thank the **Western Library of USTC** for their generously providing a room of long-term use for us making great progress there.

We sincerely thank the **University of Science and Technology of China Initiative Foundation** for their sponsorship all these years.

We sincerely thank the **School of Life Sciences, USTC** for their academic support and inspiring advice on our project.



## Project

![_DSC0630](/Users/xiebohao/Desktop/wiki_pages/Attribution/_DSC0630.JPG)

- **Management**: Wang Hao and Zhang Hao.
- **Frontend**: Yi Jingwei, Chen Lutong, Xie Bohao, Wang Tong, Yu Zihao, Gao Nan and He Liyang.
- **Backend**: He Jiyan, Ma Kai, Zhang Hao, Guan Xiuxian, Zhang Bowen and Zheng Qixuan.
- **Wiki**: Guo Yaochi and Pan Jie.
- **Art**: Li Wenrui, Xie Bohao, and Wang Tong.
- **Biology**: Zhou Yitian and Cui Meiying.
